public interface Playable {
    // Method to play
    public void play();
}